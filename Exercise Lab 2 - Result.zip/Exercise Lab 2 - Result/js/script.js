main = () => {
  function addPageButton(number) {
    let pageEl = document.getElementById("pagination-section");
    pageEl.innerHTML += `<li><a href='${url.pathname}?page=${number}'>${number}</a></li>`;
  }

  let url = new URL(document.location);
  let params = url.searchParams;
  let currentPage = params.get("page");
  currentPage = currentPage ? currentPage : 1;

  let path = url.pathname.split("/");
  path.pop();
  path = path.join("/");

  let startIndex = (currentPage - 1) * 10;
  let endIndex = Math.min(startIndex + 9, users.length - 1);
  let pageCount = Math.floor(users.length / 10);

  
  for (let i = 1; i <= pageCount + 1; i += 1) {
    addPageButton(i);
  }

  let selectedUsers = [];
  for (
    let currentIndex = startIndex;
    currentIndex <= endIndex;
    currentIndex += 1
  ) {
    selectedUsers.push(users[currentIndex]);
  }

  selectedUsers.forEach((user) => {
    let listEl = document.getElementById("contactList");
    listEl.innerHTML += `<li class="contact-item cf">
          <div class="contact-details">
            <img
              class="avatar"
              src="${user.image}"
            />
            <h3>${user.name}</h3>
          </div>
          <div class="joined-details">
            <span class="date">Joined ${user.joined}</span>
          </div>
        </li>`;
  });

  let totalEl = document.getElementById("totalCount");
  totalEl.innerText += users.length;
};

document.addEventListener("DOMContentLoaded", () => {
  main();
});
